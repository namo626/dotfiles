1.0.2
-----

- Deprecate `Math.NumberTheory.Power.Integer` and `Math.NumberTheory.Power.Natural` modules
  `(^)` is as good as custom methods.

1.0.1
-----

- Add support for `integer-simple`
