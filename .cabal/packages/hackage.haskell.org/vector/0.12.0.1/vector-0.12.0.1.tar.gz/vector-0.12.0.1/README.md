The `vector` package [![Build Status](https://travis-ci.org/haskell/vector.png?branch=master)](https://travis-ci.org/haskell/vector)
====================

An efficient implementation of Int-indexed arrays (both mutable and immutable), with a powerful loop optimisation framework.

See [`vector` on Hackage](http://hackage.haskell.org/package/vector) for more information.
