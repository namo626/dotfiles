import Sets
import Criterion.Main

main = defaultMain [Sets.benchmarks]
